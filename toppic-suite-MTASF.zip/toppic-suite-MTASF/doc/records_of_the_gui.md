﻿# Records of the GUI



This document records how do We code the GUI.

## System and software version

The system is `ubuntu 16.04 LTS`. `QT 5.5.1` and `GCC 5.4.0` is used in our program. 

## How to design a UI and create a UI file

The `*.ui` files are the UI files. They are designed on the Qt Creator. After a UI file designed, the logical code is coding on a text editor (here I used the Sublime Text 3). Then the program can be compiled by the Cmake. 
