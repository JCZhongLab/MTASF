#define BGZF_CACHE
#define BGZF_MT
#undef _USE_KNETFILE
